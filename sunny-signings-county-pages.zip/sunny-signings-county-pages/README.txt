SUNNY SIGNINGS — COUNTY PAGES
=============================

WHAT'S INSIDE
Five folders, each containing one file named index.html:

  sarasota/index.html   ->  sunnysignings.us/sarasota/
  manatee/index.html    ->  sunnysignings.us/manatee/
  charlotte/index.html  ->  sunnysignings.us/charlotte/
  lee/index.html        ->  sunnysignings.us/lee/
  collier/index.html    ->  sunnysignings.us/collier/

The FOLDER name is the label. Every file is called index.html on purpose —
that's what makes the clean URL work. Keep each file named index.html and
keep it inside its county folder. Don't rename the files.

HOW TO PUBLISH ON GITHUB
1. In your repository, upload these five folders (or drag the whole set in).
2. Commit. Each page goes live at the URL shown above within ~1 minute.
   (On GitHub: "Add file" > "Upload files" > drag the folders in.)

TWO THINGS TO FINISH
1. FORMSPREE: every booking form has action="...YOUR_FORMSPREE_CODE".
   Replace that with the same Formspree ID you use on your homepage,
   on all five pages, so submissions reach you. (A hidden "county" field
   tells you which page each lead came from.)
2. REVIEWS: the three testimonials are your real ones (Venice, Bradenton,
   Sarasota) under a "Trusted across Southwest Florida" heading. As you
   gather Google reviews per county, swap in genuine local ones.

ALSO RECOMMENDED
- Add an "Areas We Serve" link in your homepage menu pointing to the five pages.
- List the same five counties as service areas on your Google Business Profile.

Images (logo, favicon, NNA + Fidelity badges) load from your site root
(/favicon.ico, /nna_cert_logo.jpg, /fidelity.png), so they'll appear once
the pages are on sunnysignings.us alongside your existing files.
